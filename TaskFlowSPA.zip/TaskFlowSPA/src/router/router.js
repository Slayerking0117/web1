import { adminView } from "../views/admin";
import {homeView} from "../views/home";

const rutas = {
    "/admin": adminView,
    "/": homeView
}

export function router(){
    const path = window.location.pathname;
    const view = rutas[path] || notFoundView;
    document.getElementById("contenedor").innerHTML = view();
}

export function navigate(event, ruta){
    event.preventDefault();
    window.history.pushState({}, "", ruta);
    router();
}

window.addEventListener("popstate", router);

window.navigate = navigate;
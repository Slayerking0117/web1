import { adminView } from "../views/admin";

const routes = {
    "/admin": adminView
}

export function router() {
    const ruta = window.location.pathname;
    const view = routes[ruta];


if (view){
    document.getElementById ("contenedor").innerHTML = adminView()
}

}


router()
    
    


 